import { useState } from 'react';
import {
  Stethoscope,
  ClipboardList,
  ChevronDown,
  Send,
  Loader2,
  AlertCircle,
  Activity,
  ShieldCheck,
  UserRound,
} from 'lucide-react';
import { evaluateClinicalPriorities, type EvaluationResponse } from '@/lib/evaluate';

const DISCIPLINES = [
  'Nursing',
  'Radiology',
  'Dental',
  'Anaesthesia',
  'Pharmacy',
  'Medical Laboratory Technology',
] as const;

const SAMPLE_SCENARIO = `History: 58-year-old male, smoker (30 pack-years), hypertension (10 yrs), on amlodipine 10mg.
Presentation: Sudden onset crushing substernal chest pain 1 hour ago, radiating to left arm, diaphoresis, nausea. No shortness of breath currently.
Vitals: BP 160/95, HR 104, RR 20, SpO2 96% on room air, Temp 36.8C, Pain 8/10.`;

function App() {
  const [scenario, setScenario] = useState('');
  const [discipline, setDiscipline] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<EvaluationResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const canSubmit = scenario.trim().length > 0 && discipline.length > 0 && !loading;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await evaluateClinicalPriorities(scenario, discipline);
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Header */}
      <header className="bg-clinical-950 text-white shadow-lg">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
          <div className="flex items-center gap-4">
            <div className="flex-shrink-0 w-14 h-14 rounded-2xl bg-clinical-600/30 border border-clinical-400/30 flex items-center justify-center">
              <Stethoscope className="w-7 h-7 text-clinical-200" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                Clinical Data Review
              </h1>
              <p className="text-clinical-300 text-sm sm:text-base mt-1">
                KMU - 8th Semester
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 w-full">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
          {/* Stats strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
            <StatCard
              icon={<Activity className="w-5 h-5" />}
              label="Disciplines"
              value="6"
            />
            <StatCard
              icon={<ShieldCheck className="w-5 h-5" />}
              label="Model"
              value="Llama 3.3 70B"
            />
            <StatCard
              icon={<UserRound className="w-5 h-5" />}
              label="Target"
              value="KMU Students"
            />
          </div>

          {/* Form card */}
          <form
            onSubmit={handleSubmit}
            className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden"
          >
            <div className="px-6 sm:px-8 pt-6 sm:pt-8 pb-2 flex items-center gap-3">
              <ClipboardList className="w-6 h-6 text-clinical-700" />
              <h2 className="text-lg font-semibold text-clinical-950">
                Case Evaluation
              </h2>
            </div>

            <div className="px-6 sm:px-8 py-6 space-y-6">
              {/* Textarea */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label
                    htmlFor="scenario"
                    className="block text-sm font-medium text-clinical-900"
                  >
                    Enter raw patient scenario (History, Presentation, Vitals)
                  </label>
                  <button
                    type="button"
                    onClick={() => setScenario(SAMPLE_SCENARIO)}
                    className="text-xs text-clinical-600 hover:text-clinical-800 font-medium underline underline-offset-2"
                  >
                    Insert sample
                  </button>
                </div>
                <textarea
                  id="scenario"
                  value={scenario}
                  onChange={(e) => setScenario(e.target.value)}
                  rows={10}
                  placeholder="e.g. 65-year-old male presents with acute chest pain..."
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-4 py-3 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-clinical-500 focus:border-clinical-500 transition resize-y"
                />
              </div>

              {/* Dropdown */}
              <div>
                <label
                  htmlFor="discipline"
                  className="block text-sm font-medium text-clinical-900 mb-2"
                >
                  Which discipline are you?
                </label>
                <div className="relative">
                  <select
                    id="discipline"
                    value={discipline}
                    onChange={(e) => setDiscipline(e.target.value)}
                    className="w-full appearance-none rounded-xl border border-slate-300 bg-white px-4 py-3 pr-10 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-clinical-500 focus:border-clinical-500 transition"
                  >
                    <option value="" disabled>
                      Select your discipline...
                    </option>
                    {DISCIPLINES.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                </div>
              </div>

              {/* Submit */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={!canSubmit}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-clinical-700 px-6 py-3.5 text-white font-semibold text-sm sm:text-base hover:bg-clinical-800 focus:outline-none focus:ring-2 focus:ring-clinical-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Evaluating...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Evaluate Clinical Priorities
                    </>
                  )}
                </button>

                {error && (
                  <div className="mt-4 flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-red-800">
                        Evaluation failed
                      </p>
                      <p className="text-sm text-red-700 mt-0.5">{error}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </form>

          {/* Output */}
          {(loading || result || error) && (
            <div className="mt-8">
              {loading && (
                <div className="flex flex-col items-center justify-center py-16">
                  <Loader2 className="w-10 h-10 text-clinical-600 animate-spin" />
                  <p className="mt-4 text-sm text-slate-500">
                    Analyzing clinical priorities...
                  </p>
                </div>
              )}

              {!loading && result && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden animate-fade-in-up">
                  <div className="bg-clinical-800 text-white px-6 sm:px-8 py-5 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-clinical-600/40 border border-clinical-400/30 flex items-center justify-center">
                      <Stethoscope className="w-5 h-5 text-clinical-100" />
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-wider text-clinical-300">
                        Discipline Evaluation
                      </p>
                      <h3 className="text-lg font-semibold">{result.discipline}</h3>
                    </div>
                  </div>
                  <div className="px-6 sm:px-8 py-6">
                    <div className="prose prose-sm max-w-none">
                      <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-slate-700">
                        {result.evaluation}
                      </pre>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-clinical-950 text-clinical-300 text-center text-xs sm:text-sm py-5 px-4">
        Clinical Data Review - Educational use only. Developed by Maaz Ahmed.
      </footer>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 px-4 py-3 flex items-center gap-3 shadow-sm">
      <div className="w-9 h-9 rounded-lg bg-clinical-50 text-clinical-700 flex items-center justify-center">
        {icon}
      </div>
      <div>
        <p className="text-xs text-slate-500">{label}</p>
        <p className="text-sm font-semibold text-clinical-900">{value}</p>
      </div>
    </div>
  );
}

export default App;
