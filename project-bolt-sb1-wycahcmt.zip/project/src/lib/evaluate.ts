export interface EvaluationResponse {
  evaluation: string;
  discipline: string;
}

export interface EvaluationError {
  error: string;
  details?: string;
  raw?: string;
}

export async function evaluateClinicalPriorities(
  scenario: string,
  discipline: string
): Promise<EvaluationResponse> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/clinical-evaluation`;
  const headers = {
    Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
  };

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers,
    body: JSON.stringify({ scenario, discipline }),
  });

  const data = await response.json().catch(() => ({} as EvaluationError));

  if (!response.ok) {
    const errorMsg = (data as EvaluationError).error || `Request failed (${response.status})`;
    throw new Error(errorMsg);
  }

  if (!(data as EvaluationResponse).evaluation) {
    throw new Error('The response did not contain a valid evaluation.');
  }

  return data as EvaluationResponse;
}
